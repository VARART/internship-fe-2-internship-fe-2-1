export const getNotificationData = (state) => state.notifications;
