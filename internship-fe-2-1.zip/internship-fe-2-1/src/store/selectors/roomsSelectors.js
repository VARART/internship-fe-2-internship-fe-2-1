export const getRoomsState = (state) => Object.values(state.rooms);
