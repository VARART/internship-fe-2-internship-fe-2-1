export const getAccountsState = (state) => state.users.accounts;
